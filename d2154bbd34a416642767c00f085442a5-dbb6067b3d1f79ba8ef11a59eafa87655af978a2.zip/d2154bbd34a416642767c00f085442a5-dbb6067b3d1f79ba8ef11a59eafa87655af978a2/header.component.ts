import { Component, OnInit } from '@angular/core'
import { Router, RoutesRecognized, ActivatedRouteSnapshot } from '@angular/router'
import { AppRoutes } from './app-routes'
import 'rxjs/add/operator/map'
import 'rxjs/add/operator/filter'

@Component({
    selector: 'my-header',
    template: `
    <div *ngIf="routeData" class="jumbotron">
        <h1>{{ routeData.name }}</h1>
        <p>{{ routeData.description }}</p>
    </div>`
})

export class HeaderComponent implements OnInit {
    constructor(
        private router: Router
    ) { }

    routeData : any = null

    ngOnInit() {
        this.router.events
            .filter(e => e instanceof RoutesRecognized)
            .map(e => <RoutesRecognized>e)
            .subscribe((e) => {
                const currentPath = e.state.firstChild(e.state.root)._routeConfig.path
                this.routeData = AppRoutes.find(route => route.path === currentPath)
            })
    }
}