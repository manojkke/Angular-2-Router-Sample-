import { Component } from '@angular/core'
import { ROUTER_DIRECTIVES } from '@angular/router'
import { AppRoutes } from './app-routes'

@Component({
  selector: 'my-nav',
  template: `
      <ul class="nav nav-pills nav-stacked">
      <li *ngFor="let item of navItems" role="presentation" class="active"><a [routerLink]="item.path">{{item.name}}</a>
      </ul>`,
  directives: [ ROUTER_DIRECTIVES ]
})
export class NavComponent { 
    navItems = AppRoutes.filter(i => i.showInNav)
}